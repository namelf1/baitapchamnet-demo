﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3
{
    public class HinhVuong
    {
        //input
        public double a;
        //output
        public double p {  get; private set; }  

        public bool ok { get; private set; }
        public void XuLy()
        {
            //phần tính toán
            if (a <= 0)
            {
                //Console.WriteLine("Lỗi: Độ dài cạnh của hình vuông phải lớn hơn 0.");
                ok = false;
            }
            else
            {
                /// Tính chu vi
                double p = 4 * a;
                // Hiển thị chu vi
                //Console.WriteLine("Chu vi của hình vuông là: " + p);
                ok = true;
            }
        }
    }
}
