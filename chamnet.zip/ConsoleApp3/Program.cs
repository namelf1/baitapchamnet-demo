﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
